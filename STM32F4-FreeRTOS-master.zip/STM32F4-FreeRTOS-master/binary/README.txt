Resolve compilation error on Windows
